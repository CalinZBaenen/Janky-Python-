A quick note:
The 2 following programs intented to be used are: [
Janky IDLE.py
Janky Parser.py
]
if you go to resources/language/Janky.py
you can see how this language works!
I hope you like and support my project,
and if you do, please keep updating Janky
to see all the new features it will add!